const orders = [
  {id:'ORD-1048', items:['Chicken biryani','Fresh passion juice'], date:'14 Oct 2026', total:450, status:'Completed', payment:'Paid', location:'Student Cafeteria'},
  {id:'ORD-1039', items:['Beef burger','Chips','Water'], date:'11 Oct 2026', total:380, status:'Completed', payment:'Paid', location:'Campus Food Court'},
  {id:'ORD-1026', items:['Vegetable rice','Mango juice'], date:'08 Oct 2026', total:220, status:'Preparing', payment:'M-Pesa', location:'Student Cafeteria'}
];
const money = amount => 'KSh ' + amount.toLocaleString('en-KE');
const tbody = document.querySelector('#orders-body');
const searchInput = document.querySelector('#search-input');
const emptyState = document.querySelector('#empty-state');
let activeFilter = 'All';

document.querySelector('#total-orders').textContent = orders.length;
document.querySelector('#completed-orders').textContent = orders.filter(o => o.status === 'Completed').length;
document.querySelector('#total-spent').textContent = money(orders.reduce((sum,o) => sum + o.total,0));
document.querySelector('#all-count').textContent = orders.length;

function renderOrders(){
  const query = searchInput.value.trim().toLowerCase();
  const visible = orders.filter(order => {
    const matchesFilter = activeFilter === 'All' || order.status === activeFilter;
    const searchable = [order.id, order.status, ...order.items].join(' ').toLowerCase();
    return matchesFilter && searchable.includes(query);
  });
  tbody.innerHTML = visible.map(order => `
    <tr>
      <td><span class="order-id">#${order.id}</span></td>
      <td><div class="food-name">${order.items[0]}</div><div class="food-sub">${order.items.length > 1 ? '+ ' + (order.items.length-1) + ' more item(s)' : '1 item'}</div></td>
      <td class="date">${order.date}</td>
      <td class="amount">${money(order.total)}</td>
      <td><span class="status ${order.status}">${order.status}</span></td>
      <td><button class="details-btn" data-order="${order.id}">View details</button></td>
    </tr>`).join('');
  emptyState.hidden = visible.length > 0;
}
document.querySelectorAll('.filter').forEach(button => button.addEventListener('click', () => {
  document.querySelectorAll('.filter').forEach(b => b.classList.remove('active'));
  button.classList.add('active');
  activeFilter = button.dataset.filter;
  renderOrders();
}));
searchInput.addEventListener('input', renderOrders);

tbody.addEventListener('click', event => {
  const button = event.target.closest('[data-order]');
  if (!button) return;
  const order = orders.find(o => o.id === button.dataset.order);
  document.querySelector('#dialog-title').textContent = `Order #${order.id}`;
  document.querySelector('#dialog-content').innerHTML = `
    <div class="detail-line"><span>Order number</span><strong>${order.id}</strong></div>
    <div class="detail-line"><span>Food items</span><strong>${order.items.join(', ')}</strong></div>
    <div class="detail-line"><span>Order date</span><strong>${order.date}</strong></div>
    <div class="detail-line"><span>Order status</span><strong><span class="status ${order.status}">${order.status}</span></strong></div>
    <div class="detail-line"><span>Pickup location</span><strong>${order.location}</strong></div>
    <div class="detail-line"><span>Payment</span><strong>${order.payment}</strong></div>
    <div class="detail-line"><span>Total amount</span><strong class="dialog-total">${money(order.total)}</strong></div>`;
  document.querySelector('#order-dialog').showModal();
});
document.querySelector('#close-dialog').addEventListener('click', () => document.querySelector('#order-dialog').close());
document.querySelector('#order-dialog').addEventListener('click', event => {
  if(event.target === event.currentTarget) event.currentTarget.close();
});
renderOrders();
