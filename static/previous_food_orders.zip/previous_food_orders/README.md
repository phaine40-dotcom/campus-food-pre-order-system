# Previous Food Orders — Frontend Prototype

This is a standalone HTML/CSS/JavaScript frontend for the Jira story “View Previous Food Orders”.

## How to run
1. Extract `previous_food_orders.zip`.
2. Open `index.html` in Chrome, Edge, or Firefox.
3. Search for an order, filter by status, and click **View details** to see the order number, food items, date, status, pickup location, payment, and total.

## Important
The orders are sample data stored in `script.js`. This is a frontend prototype only; it is not connected to a real database or login system. Replace the sample `orders` array with data from your project's backend/API before submitting it as a fully integrated feature.

## Files
- `index.html` — page structure
- `style.css` — responsive styling
- `script.js` — sample orders, search, filters, and order detail modal
