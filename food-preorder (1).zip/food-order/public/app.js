// Front end for T0-17: select items, set quantities, review, place order, see confirmation.

const MAX_QUANTITY = 20;
const state = { menu: [], cart: new Map() }; // cart: menuItemId -> quantity

const $ = id => document.getElementById(id);
const money = n => `KSh ${n.toLocaleString('en-KE')}`;

function show(view) {
  for (const v of ['menu', 'review', 'confirm', 'orders']) $(`view-${v}`).hidden = v !== view;
  $('tab-order').classList.toggle('active', view !== 'orders');
  $('tab-orders').classList.toggle('active', view === 'orders');
  hideError();
}

function showError(messages) {
  $('error').textContent = [].concat(messages).join(' ');
  $('error').hidden = false;
}
function hideError() { $('error').hidden = true; }

function cartTotal() {
  let total = 0;
  for (const [id, qty] of state.cart) {
    const item = state.menu.find(m => m.id === id);
    if (item) total += item.price * qty;
  }
  return total;
}

function setQuantity(id, qty) {
  if (qty <= 0) state.cart.delete(id);
  else state.cart.set(id, Math.min(qty, MAX_QUANTITY));
  renderMenu();
  renderCart();
}

function renderMenu() {
  const menu = $('menu');
  menu.innerHTML = '';
  for (const item of state.menu) {
    const card = document.createElement('div');
    card.className = 'item' + (item.available ? '' : ' sold-out');
    const inCart = state.cart.get(item.id) || 0;
    card.innerHTML = `
      <div class="item-info">
        <span class="item-cat">${item.category}</span>
        <span class="item-name">${item.name}</span>
        <span class="item-price">${money(item.price)}</span>
      </div>`;
    const btn = document.createElement('button');
    if (!item.available) {
      btn.textContent = 'Sold out';
      btn.disabled = true;
    } else {
      btn.textContent = inCart ? `In cart (${inCart})` : 'Add';
      btn.addEventListener('click', () => setQuantity(item.id, inCart + 1));
    }
    card.appendChild(btn);
    menu.appendChild(card);
  }
}

function renderCart() {
  const list = $('cart-items');
  list.innerHTML = '';
  for (const [id, qty] of state.cart) {
    const item = state.menu.find(m => m.id === id);
    if (!item) continue;
    const li = document.createElement('li');
    li.innerHTML = `<span class="ci-name">${item.name}</span>`;
    const controls = document.createElement('span');
    controls.className = 'qty';
    const minus = document.createElement('button');
    minus.textContent = '−';
    minus.setAttribute('aria-label', `Remove one ${item.name}`);
    minus.addEventListener('click', () => setQuantity(id, qty - 1));
    const count = document.createElement('span');
    count.textContent = qty;
    const plus = document.createElement('button');
    plus.textContent = '+';
    plus.setAttribute('aria-label', `Add one ${item.name}`);
    plus.disabled = qty >= MAX_QUANTITY;
    plus.addEventListener('click', () => setQuantity(id, qty + 1));
    controls.append(minus, count, plus);
    const line = document.createElement('span');
    line.className = 'ci-line';
    line.textContent = money(item.price * qty);
    li.append(controls, line);
    list.appendChild(li);
  }
  $('cart-empty').hidden = state.cart.size > 0;
  $('cart-total').textContent = money(cartTotal());
  $('to-review').disabled = state.cart.size === 0;
}

function cartPayload() {
  return {
    studentId: $('student-id').value.trim(),
    items: [...state.cart].map(([menuItemId, quantity]) => ({ menuItemId, quantity })),
  };
}

async function post(url, body) {
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await res.json();
  if (!res.ok) throw data.errors || ['Something went wrong.'];
  return data;
}

async function goToReview() {
  const payload = cartPayload();
  if (!payload.studentId) return showError('Enter your student ID first.');
  try {
    const preview = await post('/api/orders/preview', payload);
    $('review-items').innerHTML = preview.items.map(i =>
      `<tr><td>${i.name}</td><td>${i.quantity}</td><td>${money(i.unitPrice)}</td><td>${money(i.lineTotal)}</td></tr>`
    ).join('');
    $('review-total').textContent = money(preview.total);
    $('review-student').textContent = payload.studentId;
    show('review');
  } catch (errors) {
    showError(errors);
  }
}

async function placeOrder() {
  $('place-order').disabled = true;
  try {
    const { order } = await post('/api/orders', cartPayload());
    $('confirm-number').textContent = order.orderNumber;
    $('confirm-total').textContent = money(order.total);
    $('confirm-status').textContent = order.status;
    state.cart.clear();
    show('confirm');
  } catch (errors) {
    showError(errors);
  } finally {
    $('place-order').disabled = false;
  }
}

async function loadMenu() {
  try {
    const res = await fetch('/api/menu');
    state.menu = await res.json();
    renderMenu();
    renderCart();
  } catch {
    $('menu').textContent = 'Could not load the menu.';
  }
}

// ---- T0-19: view active orders and cancel one ----

let pendingCancel = null;

function renderOrders(orders) {
  const list = $('orders-list');
  list.innerHTML = '';
  if (orders.length === 0) {
    list.innerHTML = '<p class="muted">You have no active orders.</p>';
    return;
  }
  for (const o of orders) {
    const card = document.createElement('div');
    card.className = 'order-card';
    const items = o.items.map(i => `${i.quantity} × ${i.name}`).join(', ');
    const placed = new Date(o.createdAt).toLocaleString('en-KE', { dateStyle: 'medium', timeStyle: 'short' });
    card.innerHTML = `
      <div class="order-head">
        <strong>${o.orderNumber}</strong>
        <span class="status status-${o.status.toLowerCase()}">${o.status}</span>
      </div>
      <p class="order-items">${items}</p>
      <p class="muted">${placed} · ${money(o.total)}</p>`;
    const btn = document.createElement('button');
    if (o.status === 'Received') {
      btn.textContent = 'Cancel order';
      btn.className = 'danger-outline';
      btn.addEventListener('click', () => askCancel(o));
    } else {
      btn.textContent = `Can't cancel, already ${o.status.toLowerCase()}`;
      btn.disabled = true;
    }
    card.appendChild(btn);
    list.appendChild(card);
  }
}

async function loadOrders() {
  hideError();
  const studentId = $('orders-student-id').value.trim();
  if (!studentId) return showError('Enter your student ID first.');
  try {
    const res = await fetch(`/api/orders?studentId=${encodeURIComponent(studentId)}`);
    const data = await res.json();
    if (!res.ok) throw data.errors;
    renderOrders(data);
  } catch (errors) {
    showError(errors || 'Could not load your orders.');
  }
}

function askCancel(order) {
  pendingCancel = order;
  $('cancel-dialog-text').textContent = `${order.orderNumber} (${money(order.total)}) will be cancelled. This can't be undone.`;
  $('cancel-dialog').showModal();
}

async function confirmCancel() {
  const order = pendingCancel;
  $('cancel-dialog').close();
  if (!order) return;
  try {
    const data = await post(`/api/orders/${encodeURIComponent(order.orderNumber)}/cancel`, {
      studentId: $('orders-student-id').value.trim(),
    });
    $('cancel-notice').textContent = data.message;
    $('cancel-notice').hidden = false;
    await loadOrders();
  } catch (errors) {
    showError(errors);
    await loadOrders();
  }
}

$('tab-order').addEventListener('click', () => show('menu'));
$('tab-orders').addEventListener('click', () => {
  if (!$('orders-student-id').value) $('orders-student-id').value = $('student-id').value;
  $('cancel-notice').hidden = true;
  show('orders');
  if ($('orders-student-id').value) loadOrders();
});
$('load-orders').addEventListener('click', () => { $('cancel-notice').hidden = true; loadOrders(); });
$('cancel-keep').addEventListener('click', () => { pendingCancel = null; $('cancel-dialog').close(); });
$('cancel-confirm').addEventListener('click', confirmCancel);

$('to-review').addEventListener('click', goToReview);
$('back-to-menu').addEventListener('click', () => show('menu'));
$('place-order').addEventListener('click', placeOrder);
$('new-order').addEventListener('click', () => { renderMenu(); renderCart(); show('menu'); });

loadMenu();
