// Tests for T0-19 Student Cancel Order, one per acceptance criterion. Run with: npm test
const { test, before, after } = require('node:test');
const assert = require('node:assert');
const { createApp } = require('../server');

let server, base, store;

before(async () => {
  const created = await createApp(); // in-memory database
  store = created.store;
  await new Promise(resolve => {
    server = created.app.listen(0, () => {
      base = `http://localhost:${server.address().port}`;
      resolve();
    });
  });
});
after(() => server.close());

const post = (path, body) =>
  fetch(base + path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) })
    .then(async r => ({ status: r.status, body: await r.json() }));
const get = path => fetch(base + path).then(async r => ({ status: r.status, body: await r.json() }));

async function placeOrder(studentId) {
  const res = await post('/api/orders', { studentId, items: [{ menuItemId: 1, quantity: 1 }] });
  return res.body.order.orderNumber;
}
const setStatus = (orderNumber, status) =>
  store.db.run('UPDATE orders SET status = ? WHERE order_number = ?', [status, orderNumber]);

test('AC1: student can view their active orders', async () => {
  const mine = await placeOrder('ALICE');
  const theirs = await placeOrder('BOB');

  const res = await get('/api/orders?studentId=ALICE');
  assert.strictEqual(res.status, 200);
  const numbers = res.body.map(o => o.orderNumber);
  assert.ok(numbers.includes(mine));
  assert.ok(!numbers.includes(theirs), "another student's order must not be listed");
  assert.ok(res.body[0].items.length > 0 && res.body[0].total > 0);

  assert.strictEqual((await get('/api/orders')).status, 400, 'student ID is required');
});

test('AC2: student can select an order to cancel', async () => {
  const order = await placeOrder('CAROL');
  const res = await post(`/api/orders/${order}/cancel`, { studentId: 'CAROL' });
  assert.strictEqual(res.status, 200);
  assert.strictEqual(res.body.order.orderNumber, order);

  // Only that order is affected
  const other = await placeOrder('CAROL');
  const list = await get('/api/orders?studentId=CAROL');
  assert.deepStrictEqual(list.body.map(o => o.orderNumber), [other]);
});

test('AC3: cancellation is allowed only before the order is prepared', async () => {
  const received = await placeOrder('DAN');
  assert.strictEqual((await post(`/api/orders/${received}/cancel`, { studentId: 'DAN' })).status, 200);

  for (const status of ['Preparing', 'Ready', 'Collected']) {
    const order = await placeOrder('DAN');
    setStatus(order, status);
    const res = await post(`/api/orders/${order}/cancel`, { studentId: 'DAN' });
    assert.strictEqual(res.status, 409, `${status} orders must not be cancellable`);
    assert.strictEqual((await get(`/api/orders/${order}`)).body.status, status, 'status must be unchanged');
  }
});

test('AC4: the system confirms that the order has been cancelled', async () => {
  const order = await placeOrder('EVE');
  const res = await post(`/api/orders/${order}/cancel`, { studentId: 'EVE' });
  assert.strictEqual(res.body.order.status, 'Cancelled');
  assert.match(res.body.message, /has been cancelled/);
  assert.match(res.body.message, new RegExp(order));

  // The change is saved, not just reported
  assert.strictEqual((await get(`/api/orders/${order}`)).body.status, 'Cancelled');
});

test('AC5: a cancelled order is no longer shown as an active order', async () => {
  const order = await placeOrder('FRANK');
  assert.ok((await get('/api/orders?studentId=FRANK')).body.some(o => o.orderNumber === order));
  await post(`/api/orders/${order}/cancel`, { studentId: 'FRANK' });
  assert.ok(!(await get('/api/orders?studentId=FRANK')).body.some(o => o.orderNumber === order));
});

test("a student cannot cancel someone else's order or cancel twice", async () => {
  const order = await placeOrder('GRACE');
  const stranger = await post(`/api/orders/${order}/cancel`, { studentId: 'MALLORY' });
  assert.strictEqual(stranger.status, 404);
  assert.strictEqual((await get(`/api/orders/${order}`)).body.status, 'Received');

  await post(`/api/orders/${order}/cancel`, { studentId: 'GRACE' });
  assert.strictEqual((await post(`/api/orders/${order}/cancel`, { studentId: 'GRACE' })).status, 409);
  assert.strictEqual((await post('/api/orders/ORD-00000000-9999/cancel', { studentId: 'GRACE' })).status, 404);
});
